1000000.times.map{|i| a={}; 4.times{|j| a[j]=j}; a}
